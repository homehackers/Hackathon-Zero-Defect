from flask import Flask, render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///expenses.db'
db = SQLAlchemy(app)


class Transaction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    category = db.Column(db.String(100), nullable=False)
    type = db.Column(db.String(20), nullable=False)  # "income" or "expense"
    date = db.Column(db.Date, nullable=False)


with app.app_context():
    db.create_all()


@app.route('/')
def index():
    transactions = Transaction.query.all()
    return render_template('index.html', transactions=transactions)


@app.route('/add', methods=['POST'])
def add_transaction():
    transaction_name = request.form['name']
    amount = float(request.form['amount'])
    category = request.form['category']
    transaction_type = request.form['type']
    

    date_str = request.form['date']
    date = datetime.strptime(date_str, '%Y-%m-%d').date() if date_str else datetime.today().date()
    

    new_transaction = Transaction(
        name=transaction_name,
        amount=amount,
        category=category,
        type=transaction_type,
        date=date
    )
    db.session.add(new_transaction)
    db.session.commit()
    return redirect(url_for('index'))


@app.route('/edit/<int:id>', methods=['GET', 'POST'])
def edit_transaction(id):
    transaction = Transaction.query.get_or_404(id)
    if request.method == 'POST':
        transaction.name = request.form['name']
        transaction.amount = float(request.form['amount'])
        transaction.category = request.form['category']
        transaction.type = request.form['type']
        

        date_str = request.form['date']
        transaction.date = datetime.strptime(date_str, '%Y-%m-%d').date() if date_str else transaction.date
        
        db.session.commit()
        return redirect(url_for('index'))
    return render_template('edit.html', transaction=transaction)

@app.route('/delete/<int:id>')
def delete_transaction(id):
    transaction = Transaction.query.get_or_404(id)
    db.session.delete(transaction)
    db.session.commit()
    return redirect(url_for('index'))


@app.route('/statistics')
def statistics():
    transactions = Transaction.query.all()
    total_expense = sum(t.amount for t in transactions if t.type == 'expense')
    total_income = sum(t.amount for t in transactions if t.type == 'income')
    return render_template('statistics.html', total_expense=total_expense, total_income=total_income)

if __name__ == '__main__':
    app.run(debug=True)
